#!/bin/sh

set -e

HASH_MANIFEST=upgrade_hashes.txt
: > "$HASH_MANIFEST"

calc_hash() {
    file="$1"
    if command -v sha256sum >/dev/null 2>&1; then
        hash_line=$(sha256sum "$file")
    elif command -v md5sum >/dev/null 2>&1; then
        hash_line=$(md5sum "$file")
    else
        echo "No hash tool found for $file" >&2
        return 1
    fi
    printf '%s\n' "$hash_line" | tee -a "$HASH_MANIFEST"
}

fetch_write_remove() {
    remote="$1"
    local_file="$2"
    offset="$3"

    if command -v tftp >/dev/null 2>&1; then
        tftp -g -r "$remote" 192.168.0.6
    else
        echo "tftp client not found" >&2
        return 1
    fi
    calc_hash "$local_file"
    filesize=$(wc -c < "$local_file" | tr -d ' ')
    echo $filesize
    mtd_debug write /dev/mtd0 "$offset" "$filesize" "$local_file"
    rm -f "$local_file"
}

mtd_debug erase /dev/mtd0 0x1000000 0x1000000

fetch_write_remove uImage uImage 0x1000000

fetch_write_remove devicetree.dtb devicetree.dtb 0x14F0000

fetch_write_remove system.bit system.bit 0x1500000

fetch_write_remove uramdisk.image.gz uramdisk.image.gz 0x1900000
